---
marp: true
theme: default
paginate: true
title: BST 258 Project Presentation
author: Minjae Kim
---

# Mediation Analysis

BST 258: Minjae Kim, Danny Lee, Tavleen Bhatia

---

## Seminal Papers / History of Causal Mediation Analysis

![w:1120](timeline_papers_simulation.svg)

---

<style scoped>
section { font-size: 24px; }
.small { font-size: 20px; }
</style>

## Robins & Greenland (1992)
### Identifiability and Exchangeability for Direct and Indirect Effects

![bg right:42% width:90%](robins_dag1_basic.png)

**Question:** Can we decompose the effect of exposure $X$ on disease $D$ into:

- **Direct effect:** $X \to D$
- **Indirect effect:** $X \to Z \to D$

**Example**

- $X$: smoking / smoking cessation
- $Z$: hyperlipidemia
- $D$: cardiovascular disease

**Main message:**  
Even if $X$ is randomized, direct and indirect effects are **not automatically identifiable**.

---

<style scoped>
section { font-size: 23px; }
</style>

## Why randomizing $X$ is not enough

![bg right:43% width:90%](robins_dag2_confounding.png)

If $X$ is randomized, the total effect is identifiable:

$$
E[D(1)] - E[D(0)]
$$

because:

$$
D(x) \perp X
$$

But mediation needs counterfactuals such as:

$$
D(x,z)
$$

meaning disease if we set exposure to $x$ and mediator to $z$.

**Problem:** $Z$ is not randomized.

So even with randomized $X$:

$$
D(x,z) \not\perp Z \mid X=x
$$

---

<style scoped>
section { font-size: 22px; }
table { font-size: 19px; }
</style>

## Nonidentifiability through causal types

Robins & Greenland classify subjects by latent **causal types**.

Each $p_j$ is the proportion of people with a certain counterfactual response pattern.

| Type | Interpretation |
|---|---|
| $p_3$ | Smoking causes disease directly; hyperlipidemia occurs but has no effect |
| $p_4$ | Smoking causes hyperlipidemia, which causes disease |
| $p_5$ | Smoking causes both hyperlipidemia and disease directly |
| $p_7$ | Smoking causes disease directly; hyperlipidemia never occurs |

Without interaction:

$$
\text{Total effect}=p_3+p_4+p_5+p_7
$$

$$
\text{Direct effect}=p_3+p_5+p_7,
\qquad
\text{Indirect effect}=p_4
$$

**Key issue:** different causal-type mixtures can generate the same observed data.

---

<style scoped>
section { font-size: 23px; }
</style>

## Partial exchangeability

To identify mediation effects, they assume:

$$
R_{11B}=R_{10},
\qquad
R_{01B}=R_{00}
$$

Interpretation:

- $R_{11B}$: risk among smoking hyperlipidemics **if hyperlipidemia were blocked**
- $R_{10}$: observed risk among smoking normolipidemics
- $R_{01B}$: risk among quitting hyperlipidemics **if hyperlipidemia were blocked**
- $R_{00}$: observed risk among quitting normolipidemics

Modern version:

$$
D(x,z) \perp Z \mid X=x,C
$$

Then G-computation identifies:

$$
E[D(x,z)] =
\sum_c E[D \mid X=x,Z=z,C=c]P(C=c)
$$

---

<style scoped>
section { font-size: 23px; }
</style>

## Exposure-induced confounding and takeaway

![bg right:43% width:90%](robins_dag3_postexp.png)

A hard case occurs when exposure affects a mediator-outcome confounder:

$$
X \to L,\qquad L \to Z,\qquad L \to D
$$

Then:

- adjusting for $L$ may block part of the effect of $X$
- not adjusting for $L$ leaves $Z \to D$ confounded

### Takeaway

Robins & Greenland show that:

1. total effects are easier than mediation effects;
2. stratifying on $Z$ can be biased;
3. direct/indirect effects require strong assumptions;
4. interaction makes decomposition even harder.

This motivates Pearl’s later formal definitions of CDE, NDE, and NIE.

---

<style scoped>
section { font-size: 22px; }
</style>

## Pearl (2001): Direct and Indirect Effects

![bg right:42% width:90%](pearl_dag1_basic.png)

Pearl’s goal was to extend mediation analysis beyond linear path models.

### Main contribution

Define direct and indirect effects using **structural counterfactuals**:

- **Controlled direct effect**
- **Natural direct effect**
- **Natural indirect effect**
- **Path-specific effects**

### Basic mediation DAG

$$
X \to Z \to Y,
\qquad
X \to Y
$$

**Key idea:**  
Some causal questions require modifying **paths**, not simply fixing variables.

---

<style scoped>
section { font-size: 23px; }
</style>

## Controlled Direct Effect: prescriptive

![bg right:42% width:90%](pearl_dag1_basic.png)

The **controlled direct effect** asks:

> What is the effect of changing $X$ while fixing the mediator $Z$ at a chosen level $z$?

$$
CDE_z(x,x^*;Y)
=
E[Y_{xz}] - E[Y_{x^*z}]
$$

### Interpretation

We prescribe the same mediator level $z$ for everyone.

Example:

- Compare treated vs. untreated
- while forcing everyone to take the same aspirin dose

### Important point

CDE is usually easier to interpret as an intervention:

$$
do(X=x, Z=z)
$$

---

<style scoped>
section { font-size: 22px; }
</style>

## Natural Direct Effect: descriptive

The **natural direct effect** asks:

> What is the effect of changing $X$ while keeping $Z$ at the value it would naturally have under $X=x^*$?

$$
NDE(x,x^*;Y)
=
E[Y_{x,Z_{x^*}}] - E[Y_{x^*}]
$$

### Intuition

We compare:

$$
Y_{x,Z_{x^*}}
\quad \text{vs.} \quad
Y_{x^*}
$$

So we change $X$, but keep the mediator at its natural reference-world value.

### Why this is hard

This is a **nested / cross-world counterfactual**:

$$
Y_{x,Z_{x^*}}
$$

It combines the world where $X=x$ with the mediator value from the world where $X=x^*$.

---

<style scoped>
section { font-size: 21px; }
</style>

## Natural Indirect Effect and decomposition

The **natural indirect effect** asks:

> What would happen if $X$ stayed at $x^*$, but $Z$ changed to the value it would have under $X=x$?

$$
NIE(x,x^*;Y)
=
E[Y_{x^*,Z_x}] - E[Y_{x^*}]
$$

Pearl defines the total effect as:

$$
TE(x,x^*;Y)
=
E[Y_x] - E[Y_{x^*}]
$$

Pearl’s decomposition is:

$$
TE(x,x^*;Y)
=
NIE(x,x^*;Y) - NDE(x^*,x;Y)
$$

**Important:** the NDE term is for the **reverse transition**, from $x$ back to $x^*$.

In linear/additive models,

$$
NDE(x^*,x;Y) = -NDE(x,x^*;Y)
$$

so this becomes the familiar expression:

$$
TE = NDE + NIE
$$

---

<style scoped>
section { font-size: 22px; }
</style>

## Identification: cross-world independence + mediation formula

![bg right:40% contain](pearl_dag2_mediation_formula.png)

Natural effects are not identified automatically because they involve nested counterfactuals:

$$
Y_{x,Z_{x^*}}
$$

This combines two worlds:

- the outcome world where $X=x$
- the mediator value from the reference world where $X=x^*$

Let $S$ denote measured covariates sufficient for identification.

Pearl requires a **cross-world independence** condition:

$$
Y_{xz} \perp\!\!\!\perp Z_{x^*} \mid S
$$

Under appropriate graphical conditions, the NDE is identified by:

$$
NDE(x,x^*;Y)
=
\sum_s \sum_z
\{E[Y \mid x,z,s] - E[Y \mid x^*,z,s]\}
P(z \mid x^*,s)P(s)
$$

---

<style scoped>
section { font-size: 22px; }
</style>

## Path-specific effects

![bg right:42% width:90%](pearl_dag3_path_specific.png)

Pearl generalizes mediation to **path-specific effects**.

Instead of asking only:

$$
X \to Z \to Y
$$

we can ask about any selected causal path, such as:

$$
X \to Z \to W \to Y
$$

### Key idea

To isolate a path-specific effect, we do not simply fix nodes.

We instead modify the structural equations so that some paths carry $x$ and other paths carry $x^*$.

### Takeaway

Pearl’s paper formalizes mediation as a problem of:

- path activation / deactivation
- nested counterfactuals
- graphical identification

This sets up later debates about cross-world assumptions.

---

## Conceptual Issues in Mediation Analysis
### VanderWeele and Vansteelandt (2009)

---
## Modern Version Summary 
**A1. No unmeasured confounding assumption for the exposure-outcome:**
$$
Y(a, m) \perp A | (C_1 \cup C_2)
$$
**A2. No unmeasured confounding assumption for the mediator-outcome:**
$$
Y(a, m) \perp M | A, (C_1 \cup C_2)
$$
**A3. No unmeasured confounding assumption for the exposure-mediator relationship:**
$$
M(a) \perp A | (C_1 \cup C_2)
$$
**A4. Cross-world independence:**
$$
Y(a, m) \perp M(a^*) | (C_1 \cup C_2)
$$
![bg right:40% width:95%](Dag_fig1_vanderweele.png)

---

$$
\underbrace{E[Y(a')] - E[Y(a)]}_{\text{average causal effect}}
$$
$$
= \underbrace{E[Y(a')] - E[Y(a', M(a))]}_{\text{total indirect effect}}
+ \underbrace{E[Y(a', M(a))] - E[Y(a)]}_{\text{pure direct effect}} \\
$$
$$
=
\underbrace{E[Y(a')] - E[Y(a, M(a'))]}_{\text{total direct effect}}
+\underbrace{E[Y(a, M(a'))] - E[Y(a)]}_{\text{pure indirect effect}}.
$$
---
## Exposure-induced confounder
![width:95%](Dag_fig2_vanderweele.png)

---

## Conceptual Issues

**1. Cross-world Independence:** Can be problematic **if the mediator is measured much later than the time that exposure takes place.** This is because of the exposure-induced confounder. 
- Consider the exposure-induced confounder, $L$. 
- Consider the NPSEM 
$\mathbf{L = f_L(A, U_L)}$, $M = f_M(A, L, U_M)$, $Y = f_Y(A, M, L, U_Y)$.

---

$$
\left.
\begin{aligned}
L(a^*) &= f_L(a^*, U_L) \\
M(a^*) &= f_M(a^*, L(a^*), U_M)
       = f_M(a^*, f_L(a^*, U_L), U_M)
\end{aligned}
\right\}
\quad \text{share } U_L
$$

$$
\left.
\begin{aligned}
L(a) &= f_L(a, U_L) \\
Y(a,m) &= f_Y(a,m,L(a),U_Y)
       = f_Y(a,m,f_L(a,U_L),U_Y)
\end{aligned}
\right\}
\quad \text{share } U_L
$$

### Therefore, we see that cross-world independence is violated due to $U_L$:

$$Y(a,m) \not\!\perp\!\!\!\perp M(a^*)$$

---

## Conceptual Issues

**2. Infeasible intervention on the mediator:** In our framework, we consider the mediator to be the intervention node as well. **But sometimes, mediators of interest cannot be intervened.**

VanderWeele cites a psychology study by Nelson et al. (1997) where the **mediator was general political attitudes towards the right to free speech and the maintenance of public order.** We cannot intervene on political attitudes directly. 

---

## Conceptual Issues

**3. Composition assumption:** In many cases,  **it is difficult to think of interventions that non-invasively fix the mediator.**
- **Natural setting:** Setting $A=a$ and then "letting $M$ naturally become $M(a)$" via only an intervention on the exposure node
-  **"Forced" natural setting:** is a very different physical action than setting $A=a$ and forcing $M$ to become $M(a)$ via some external mechanism. 

---

## Defending the Composition Assumption

- The **consistency assumption $Y=Y(a, m)$ given $A=a, M=m$ already entails the assumption of noninvasive intervention on the mediator.**

- Thus, if a researcher accepts composition, no philosophical reason to not accept the composition.

---

## Alternative to Cross-world independence: No-interaction
$Y(a, m) - Y(0, m)$ is a random variable that does not depend on $m$. 
In this case, $Y(a, m) - Y(0, m) = Y(a, M(0)) - Y(0, M(0))$ holds, and thus the conditional controlled direct effect at any fixed $m$ is equal to the conditional natural direct effect.
$$E[Y(a, m) - Y(0, m) \mid C] = E[Y(a, M(0)) - Y(0, M(0)) \mid C]$$
$$CCDE(m) = CNDE$$

---

## Simulation Study
### (Robins et al. 2022)

---
## River Blindness Study 
### (Robins et al. 2022)

![bg right:40% width:95%](fig_swig1.png)

- $A$ is the indicator of being randomized into the study
- $M$ is the indciator of being treated with Ivermectin, the river blindness medicine.
- Ivermectin is assumed to be commercially available, so $A=0$ group can still self-treat Ivermectin in their own discretion.
- $U$ is an unmeasured confounder, $S$ and $R$ lost due to fire.

---
## River Blindness Study 
-  Due to Ivermectin side-effects, an immunosuppressive therapy may be required at a nearby clinic established by the investigators.

- $S$ is the indicator of access to the clinic, and $R$ the indicator of immunosuppressive therapy. 



![bg right:40% width:95%](fig_swig2.png)

---
## River Blindness Study 

- The patients not selected into $A=1$ do not have access to immmunosuppression nor the clinic, thus $S=0$, $R=0$ for them. 

- $S=1$ iff $A=1$. 
- **No arrow from $U$ to $R(0, m)$ since $R(0, m) \equiv 0$.**
- **No arrow from $U$ to $M(1)$ since $a=1$ means randomized.**


![bg right:40% width:85%](fig_swig2.png)

---

## River Blindness Study 

### Are we allowed to ignore the inaccessible variables and simpify the diagram to the left version? No.
![width:300px](naive_dag.png) ![width:490px](fig_swig1.png)

---

## Cross-world confounding pathway
Consider the new SWIG.
$$M(a=0) \leftarrow U \rightarrow R(s=1, m) \rightarrow Y(s=1, m)$$

$$\text{Therefore, } \mathbf{M(a=0) \not\perp Y(s=1, m)}.$$
Recall that $A$ determines $S$ completely. In particular, $A=S$ and $S(a=1) = 1$ always holds. 

$$\therefore Y(s=1, m) = Y(a=1, m)$$


$$\textbf{Therefore, } \mathbf{Y(a=1, m) \not\perp M(a=0)}$$

![bg right:50% width:100%](SWIG_disprove_crossworld.png)


---

## Interventionist Framework (By Robins, motivated by Pearl)
### Robins, Richardson, Shpitser (2022)

---
## Pearl's Setup and an Argument on why PDE may be of interest

- $A$: smoking status (binary)
- $M$: hypertension status (binary)
- $Y$: outcome of myocardial infarction (MI) (binary)

**Setup: Nicotine is the only component of cigarette that affects $M$**

**Question of interest: Causal effect of providing nicotine-free cigarettes to smokers**
 
**Why?: They will have the hypertension level same as to that of the non-smokers, $M(a=0)$.** Thus, the following is an interesting quantity:
$$
PDE = E[Y(a=1, M(a=0))] - E[Y(a=0, M(a=0))]
$$

---
## Reformulation of the problem 

Let $O$ be other components of cigar then nicotine. $M$ is only affected by $N$, not $O$. 

$$
\mathbf{PDE = E[Y(n=0, o=1)] - E[Y(n=0, o=0)]}
$$

Consider 3 cases of the data:
1. The original observed data where **$\mathbf{A}$ was randomized**, $(A, M, Y)$. 
2. A "Desirable" data from **four-arm randomization of $\mathbf{(N, O)}$**, with counterfactuals $(M(n, o), Y(n, o))$ observed for $(n, o) \in \{0, 1\}^2$. 
3. **A censored version of the four-arm data**, where only $n=o$ cases are given to us.

![bg right:40% width:85%](interventionist_SWIG.png)

---
## Reformulation of the problem

We should see that data 1 allows us to identify the distribution of the data 3 by:
$$\begin{aligned}
p(M=m, Y=y | A=a) \\
&= p(M(n=a, o=a)=m, Y(n=a, o=a)=y | A=a) \\
&= p(M(n=a, o=a)=m, Y(n=a, o=a)=y)
\end{aligned}$$

The first line holds due to determinism $A=N=O$, and the second line holds from $\{M(n, o), Y(n, o)\} \perp A$ from the SWIG.

---
## Identification using the reformulated setup

Proposition 1 in  Robins et al. (2022):
**Under our SWIG, the 4-arm study's counterfactual outcomes are identifiable using the data of the $A$-randomized study.**


![bg right:40% width:85%](interventionist_SWIG.png)