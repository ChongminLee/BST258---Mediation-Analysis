---
marp: false
theme: default
paginate: true
title: BST 258 Project Presentation
author: Minjae Kim

---

# Mediation Analysis

BST 258: Minjae Kim, Danny Lee, Tavleen Bhatia

---

## Seminal Papers / History of Causal Mediation Analysis

![w:1120](timeline_papers_simulation.svg)

---


<style scoped>
section { font-size: 24px; }
</style>

## Baron and Kenny (1986)
### The Foundational Regression-Based Approach

---

<style scoped>
section { font-size: 23px; }
</style>

## Why Mediation?

- Establishing that $X$ affects $Y$ is only the **beginning** of a causal inquiry
- The deeper question: **how** or **why** does the effect occur?
- A **mediator** $M$ represents the mechanism through which $X$ influences $Y$

**Key distinction Baron & Kenny insisted on:**

- **Moderator:** changes the *strength or direction* of $X \to Y$ — appears as an interaction term
- **Mediator:** explains the *mechanism* of $X \to Y$ — lies on the causal pathway

These were routinely conflated in psychology before 1986.

---

<style scoped>
section { font-size: 22px; }
</style>

## The Mediation Path Diagram

$$
X \xrightarrow{a} M \xrightarrow{b} Y
$$

$$
X \xrightarrow{c} Y 
\quad \xrightarrow{\text{becomes}} \quad 
X \xrightarrow{c'} Y \text{ (controlling for } M\text{)}
$$

- Path $a$: effect of $X$ on the mediator $M$
- Path $b$: effect of $M$ on $Y$, controlling for $X$
- Path $c$: total effect of $X$ on $Y$
- Path $c'$: **direct** effect of $X$ on $Y$ after controlling for $M$

**Perfect mediation:** $c' = 0$ — $X$ has no effect on $Y$ once $M$ is controlled

---

<style scoped>
section { font-size: 22px; }
</style>

## The Four-Step Procedure

To establish mediation, estimate three regression equations and verify:

1. **Step 1:** Regress $M$ on $X$ — confirm $X$ significantly predicts $M$  
   path $a$

2. **Step 2:** Regress $Y$ on $X$ alone — confirm $X$ significantly predicts $Y$  
   path $c$

3. **Step 3:** Regress $Y$ on both $X$ and $M$ — confirm:

   - $M$ significantly predicts $Y$  
     path $b$
   - Coefficient on $X$ is **smaller** than in Step 2

**When all conditions hold**, $M$ is a mediator. The stronger the reduction in $c \to c'$, the stronger the mediation.

---

<style scoped>
section { font-size: 22px; }
</style>

## The Sobel Test

Sobel (1982) provides a significance test for the **indirect effect** $ab$:

$$
\widehat{\text{se}}(ab) 
\approx 
\sqrt{b^2 s_a^2 + a^2 s_b^2}
$$

where $s_a$, $s_b$ are standard errors of paths $a$ and $b$ respectively.

- Allows a $z$-test of $H_0: ab = 0$
- Became the standard compact test for mediation in applied psychology
- Used widely for two decades after the paper

---

<style scoped>
section { font-size: 22px; }
</style>

## What the Paper Gets Right

- Provided a **clear, testable, operational definition** of mediation
- Connected directly to regression tools researchers already knew
- Established the vocabulary — *moderator vs. mediator* — that the whole field now uses
- The four-step procedure is intuitive and easy to implement

The 1986 paper is one of the **most cited papers in all of social science** for good reason: it gave empirical researchers a concrete procedure where none existed before.

---

<style scoped>
section { font-size: 21px; }
</style>

## What the Paper Silently Assumes

**1. Linearity and no interaction:** OLS regression implicitly assumes $X$ and $M$ do not interact in producing $Y$ — the direct and indirect effects are assumed to **add up** to the total effect.

**2. No unmeasured** $M \to Y$ confounding: The coefficient on $M$ in Step 3 is treated as causal — requires no common causes of $M$ and $Y$ outside the model. **Never stated.**

**3. No formal causal framework:** No DAGs, no counterfactuals, no do-calculus. Coefficients are given causal meaning purely by convention.

**4. No discussion of identifiability:** Whether direct and indirect effects can even be recovered from data — even in a randomized trial — is never raised.

---

## Robins & Greenland (1992)
### Identifiability and Exchangeability for Direct and Indirect Effects

---
<style scoped>
section { font-size: 24px; }
.small { font-size: 20px; }
</style>

![bg right:42% width:90%](robins_dag1_basic.png)

**Question:** Can we decompose the effect of exposure $X$ on disease $D$ into:

- **Direct effect:** $X \to D$
- **Indirect effect:** $X \to Z \to D$

**Example**

- $X$: smoking / smoking cessation
- $Z$: hyperlipidemia
- $D$: cardiovascular disease

**Main message:**  
Even if $X$ is randomized, direct and indirect effects are **not automatically identifiable**.

---

<style scoped>
section { font-size: 23px; }
</style>

## Why randomizing $X$ is not enough

![bg right:43% width:90%](robins_dag2_confounding.png)

If $X$ is randomized, the total effect is identifiable:

$$
E[D(1)] - E[D(0)]
$$

because:

$$
D(x) \perp X
$$

But mediation needs counterfactuals such as:

$$
D(x,z)
$$

meaning disease if we set exposure to $x$ and mediator to $z$.

**Problem:** $Z$ is not randomized.

So even with randomized $X$:

$$
D(x,z) \not\perp Z \mid X=x
$$

---

<style scoped>
section { font-size: 22px; }
table { font-size: 19px; }
</style>

## Nonidentifiability through causal types

Robins & Greenland classify subjects by latent **causal types**.

Each $p_j$ is the proportion of people with a certain counterfactual response pattern.

| Type | Interpretation |
|---|---|
| $p_3$ | Smoking causes disease directly; hyperlipidemia occurs but has no effect |
| $p_4$ | Smoking causes hyperlipidemia, which causes disease |
| $p_5$ | Smoking causes both hyperlipidemia and disease directly |
| $p_7$ | Smoking causes disease directly; hyperlipidemia never occurs |

Without interaction:

$$
\text{Total effect}=p_3+p_4+p_5+p_7
$$

$$
\text{Direct effect}=p_3+p_5+p_7,
\qquad
\text{Indirect effect}=p_4
$$

**Key issue:** different causal-type mixtures can generate the same observed data.

---

<style scoped>
section { font-size: 23px; }
</style>

## Partial exchangeability

To identify mediation effects, they assume:

$$
R_{11B}=R_{10},
\qquad
R_{01B}=R_{00}
$$

Interpretation:

- $R_{11B}$: risk among smoking hyperlipidemics **if hyperlipidemia were blocked**
- $R_{10}$: observed risk among smoking normolipidemics
- $R_{01B}$: risk among quitting hyperlipidemics **if hyperlipidemia were blocked**
- $R_{00}$: observed risk among quitting normolipidemics

Modern version:

$$
D(x,z) \perp Z \mid X=x,C
$$

Then G-computation identifies:

$$
E[D(x,z)] =
\sum_c E[D \mid X=x,Z=z,C=c]P(C=c)
$$

---

<style scoped>
section { font-size: 23px; }
</style>

## Exposure-induced confounding and takeaway

![bg right:43% width:90%](robins_dag3_postexp.png)

A hard case occurs when exposure affects a mediator-outcome confounder:

$$
X \to L,\qquad L \to Z,\qquad L \to D
$$

Then:

- adjusting for $L$ may block part of the effect of $X$
- not adjusting for $L$ leaves $Z \to D$ confounded

### Takeaway

Robins & Greenland show that:

1. total effects are easier than mediation effects;
2. stratifying on $Z$ can be biased;
3. direct/indirect effects require strong assumptions;
4. interaction makes decomposition even harder.

This motivates Pearl’s later formal definitions of CDE, NDE, and NIE.

---

## Direct and Indirect Effects
### Pearl (2001)

---
<style scoped>
section { font-size: 22px; }
</style>
![bg right:42% width:90%](pearl_dag1_basic.png)

Pearl’s goal was to extend mediation analysis beyond linear path models.

### Main contribution

Define direct and indirect effects using **structural counterfactuals**:

- **Controlled direct effect**
- **Natural direct effect**
- **Natural indirect effect**
- **Path-specific effects**

### Basic mediation DAG

$$
X \to Z \to Y,
\qquad
X \to Y
$$

**Key idea:**  
Some causal questions require modifying **paths**, not simply fixing variables.

---

<style scoped>
section { font-size: 23px; }
</style>

## Controlled Direct Effect: prescriptive

![bg right:42% width:90%](pearl_dag1_basic.png)

The **controlled direct effect** asks:

> What is the effect of changing $X$ while fixing the mediator $Z$ at a chosen level $z$?

$$
CDE_z(x,x^*;Y)
=
E[Y_{xz}] - E[Y_{x^*z}]
$$

### Interpretation

We prescribe the same mediator level $z$ for everyone.

Example:

- Compare treated vs. untreated
- while forcing everyone to take the same aspirin dose

### Important point

CDE is usually easier to interpret as an intervention:

$$
do(X=x, Z=z)
$$

---

<style scoped>
section { font-size: 22px; }
</style>

## Natural Direct Effect: descriptive

The **natural direct effect** asks:

> What is the effect of changing $X$ while keeping $Z$ at the value it would naturally have under $X=x^*$?

$$
NDE(x,x^*;Y)
=
E[Y_{x,Z_{x^*}}] - E[Y_{x^*}]
$$

### Intuition

We compare:

$$
Y_{x,Z_{x^*}}
\quad \text{vs.} \quad
Y_{x^*}
$$

So we change $X$, but keep the mediator at its natural reference-world value.

### Why this is hard

This is a **nested / cross-world counterfactual**:

$$
Y_{x,Z_{x^*}}
$$

It combines the world where $X=x$ with the mediator value from the world where $X=x^*$.

---

<style scoped>
section { font-size: 21px; }
</style>

## Natural Indirect Effect and decomposition

The **natural indirect effect** asks:

> What would happen if $X$ stayed at $x^*$, but $Z$ changed to the value it would have under $X=x$?

$$
NIE(x,x^*;Y)
=
E[Y_{x^*,Z_x}] - E[Y_{x^*}]
$$

Pearl defines the total effect as:

$$
TE(x,x^*;Y)
=
E[Y_x] - E[Y_{x^*}]
$$

Pearl’s decomposition is:

$$
TE(x,x^*;Y)
=
NIE(x,x^*;Y) - NDE(x^*,x;Y)
$$

**Important:** the NDE term is for the **reverse transition**, from $x$ back to $x^*$.

In linear/additive models,

$$
NDE(x^*,x;Y) = -NDE(x,x^*;Y)
$$

so this becomes the familiar expression:

$$
TE = NDE + NIE
$$

---

<style scoped>
section { font-size: 22px; }
</style>

## Identification: cross-world independence + mediation formula

![bg right:40% contain](pearl_dag2_mediation_formula.png)

Natural effects are not identified automatically because they involve nested counterfactuals:

$$
Y_{x,Z_{x^*}}
$$

This combines two worlds:

- the outcome world where $X=x$
- the mediator value from the reference world where $X=x^*$

Let $S$ denote measured covariates sufficient for identification.

Pearl requires a **cross-world independence** condition:

$$
Y_{xz} \perp\!\!\!\perp Z_{x^*} \mid S
$$

Under appropriate graphical conditions, the NDE is identified by:

$$
NDE(x,x^*;Y)
=
\sum_s \sum_z
\{E[Y \mid x,z,s] - E[Y \mid x^*,z,s]\}
P(z \mid x^*,s)P(s)
$$

---

<style scoped>
section { font-size: 22px; }
</style>

## Path-specific effects

![bg right:42% width:90%](pearl_dag3_path_specific.png)

Pearl generalizes mediation to **path-specific effects**.

Instead of asking only:

$$
X \to Z \to Y
$$

we can ask about any selected causal path, such as:

$$
X \to Z \to W \to Y
$$

### Key idea

To isolate a path-specific effect, we do not simply fix nodes.

We instead modify the structural equations so that some paths carry $x$ and other paths carry $x^*$.

### Takeaway

Pearl’s paper formalizes mediation as a problem of:

- path activation / deactivation
- nested counterfactuals
- graphical identification

This sets up later debates about cross-world assumptions.

---

## Conceptual Issues in Mediation Analysis
### VanderWeele and Vansteelandt (2009)

---
## Modern Version Summary 
**A1. No unmeasured confounding assumption for the exposure-outcome:**
$$
Y(a, m) \perp A | (C_1 \cup C_2)
$$
**A2. No unmeasured confounding assumption for the mediator-outcome:**
$$
Y(a, m) \perp M | A, (C_1 \cup C_2)
$$
**A3. No unmeasured confounding assumption for the exposure-mediator relationship:**
$$
M(a) \perp A | (C_1 \cup C_2)
$$
**A4. Cross-world independence:**
$$
Y(a, m) \perp M(a^*) | (C_1 \cup C_2)
$$
![bg right:40% width:95%](Dag_fig1_vanderweele.png)

---

$$
\underbrace{E[Y(a')] - E[Y(a)]}_{\text{average causal effect}}
$$
$$
= \underbrace{E[Y(a')] - E[Y(a', M(a))]}_{\text{total indirect effect}}
+ \underbrace{E[Y(a', M(a))] - E[Y(a)]}_{\text{pure direct effect}} \\
$$
$$
=
\underbrace{E[Y(a')] - E[Y(a, M(a'))]}_{\text{total direct effect}}
+\underbrace{E[Y(a, M(a'))] - E[Y(a)]}_{\text{pure indirect effect}}.
$$
---
## Exposure-induced confounder
![width:95%](Dag_fig2_vanderweele.png)

---

## Conceptual Issues

**1. Cross-world Independence:** Can be problematic **if the mediator is measured much later than the time that exposure takes place.** This is because of the exposure-induced confounder. 
- Consider the exposure-induced confounder, $L$. 
- Consider the NPSEM 
$\mathbf{L = f_L(A, U_L)}$, $M = f_M(A, L, U_M)$, $Y = f_Y(A, M, L, U_Y)$.

---

$$
\left.
\begin{aligned}
L(a^*) &= f_L(a^*, U_L) \\
M(a^*) &= f_M(a^*, L(a^*), U_M)
       = f_M(a^*, f_L(a^*, U_L), U_M)
\end{aligned}
\right\}
\quad \text{share } U_L
$$

$$
\left.
\begin{aligned}
L(a) &= f_L(a, U_L) \\
Y(a,m) &= f_Y(a,m,L(a),U_Y)
       = f_Y(a,m,f_L(a,U_L),U_Y)
\end{aligned}
\right\}
\quad \text{share } U_L
$$

### Therefore, we see that cross-world independence is violated due to $U_L$:

$$Y(a,m) \not\!\perp\!\!\!\perp M(a^*)$$

---

## Conceptual Issues

**2. Infeasible intervention on the mediator:** In our framework, we consider the mediator to be the intervention node as well. **But sometimes, mediators of interest cannot be intervened.**

VanderWeele cites a psychology study by Nelson et al. (1997) where the **mediator was general political attitudes towards the right to free speech and the maintenance of public order.** We cannot intervene on political attitudes directly. 

---

## Conceptual Issues

**3. Composition assumption:** In many cases,  **it is difficult to think of interventions that non-invasively fix the mediator.**
- **Natural setting:** Setting $A=a$ and then "letting $M$ naturally become $M(a)$" via only an intervention on the exposure node
-  **"Forced" natural setting:** is a very different physical action than setting $A=a$ and forcing $M$ to become $M(a)$ via some external mechanism. 

---

## Defending the Composition Assumption

- The **consistency assumption $Y=Y(a, m)$ given $A=a, M=m$ already entails the assumption of noninvasive intervention on the mediator.**

- Thus, if a researcher accepts composition, no philosophical reason to not accept the composition.

---

## Alternative to Cross-world independence: No-interaction
$Y(a, m) - Y(0, m)$ is a random variable that does not depend on $m$. 
In this case, $Y(a, m) - Y(0, m) = Y(a, M(0)) - Y(0, M(0))$ holds, and thus the conditional controlled direct effect at any fixed $m$ is equal to the conditional natural direct effect.
$$E[Y(a, m) - Y(0, m) \mid C] = E[Y(a, M(0)) - Y(0, M(0)) \mid C]$$
$$CCDE(m) = CNDE$$

---

## Insights into the cross-world independence assumption
### Andrews and Didelez, 2020
---
<style scoped>
section { font-size: 21px; }
</style>

## The Knee Surgery Example

**Setting:** Effect of knee replacement surgery ($A$) on quality of life ($Y$) through walking speed ($M$)

An unobserved genetic marker $U$:

- Slows walking speed **without surgery** — affects $M(0)$
- Causes surgical scarring **with surgery** — affects $Y(1,m)$ via scarring $S$
- Scarring does **not** affect walking speed — so no $S \to M$ edge, no intermediate confounding

**Result:**

$$
Y(1,m) = Y(1,S(1),m) 
\not\!\!\perp\!\!\!\perp M(0)
$$

because both depend on the common $U$.

**Key lesson:** Absence of intermediate confounding is **not sufficient** to justify cross-world independence. A subject-matter audit of cross-world pathways is required.

---

<style scoped>
section { font-size: 20px; }
</style>

## When NDE and NIE Are Identified

When assumptions — FFRCISTG + cross-world independence — all hold, the **mediation g-formula** identifies NDE and NIE:

$$
\widehat{\text{NDE}} 
=
\sum_m 
\big(
E\{Y \mid A=a, M=m\} 
- 
E\{Y \mid A=a^*, M=m\}
\big)
p(M=m \mid A=a^*)
$$

$$
\widehat{\text{NIE}} 
=
\sum_m 
E\{Y \mid A=a, M=m\}
\big(
p(M=m \mid A=a) 
- 
p(M=m \mid A=a^*)
\big)
$$

When cross-world independence **fails**, these formulas are still computable — but they are **biased** for the true NDE and NIE.

---

<style scoped>
section { font-size: 19px; }
</style>

## Alternatives to Cross-World Independence

**1. Bounds** — under FFRCISTG assumptions alone, NDE is not point-identified but can be bounded. For binary $A, M, Y$:


$$LB = \sum_{m \in \{0,1\}} \max(0, E[Y|A=1, M=m] + P(M=m|A=0) - 1) - E[Y|A=0]$$

$$UB = \sum_{m \in \{0,1\}} \min(E[Y|A=1, M=m], P(M=m|A=0)) - E[Y|A=0]$$

Often wide — quantify what data alone can tell us without cross-world assumptions.

**2. Parametric assumptions** — e.g. no additive interaction:

$$
Y(a,m) - Y(a^*,m) = B(a,a^*) 
\text{ does not depend on } m
$$

Then NDE $= E\{B(a,a^*)\}$ is identified from single-world quantities alone.

**3. Alternative estimands** — redefine the target:

- **Interventional effects:** set $M$ to a random draw from $p(M(a^*))$ rather than the individual-specific $M(a^*)$
- **Separable effects** — Robins & Richardson: decompose $A$ into components $A^M$ and $A^Y$ — entirely single-world, motivates the interventionist approach of Robins et al. (2022)

---

<style scoped>
section { font-size: 19px; }
table { font-size: 18px; }
</style>

## Numerical Illustration of Bias

Andrews & Didelez simulate the knee surgery DGP where cross-world independence is violated **but no intermediate confounding exists** — isolating the effect of cross-world confounding alone.

They compute Pearl's g-formula and compare to the true NDE over 327,680 parameter settings:

| Outcome | Bias range | Max relative bias |
|---|---|---|
| Continuous $Y$ | $-3.3$ to $+3.3$ SD | Driven by 3-way interaction $\beta_5$ |
| Binary $Y$ with $\beta_5 \neq 0$ | $-0.04$ to $+0.04$ | Up to **70%** |

- Bias is **zero** when the 3-way $A \times M \times U$ interaction $\beta_5 = 0$  
  linear case
- Bounds were informative but wide — could not replace the cross-world assumption

**Takeaway:** Cross-world confounding is not just a theoretical concern — it can produce substantial bias in realistic settings.

---
## Simulation Study
### (Robins et al. 2022)

---
## River Blindness Study 
### (Robins et al. 2022)

![bg right:40% width:95%](fig_swig1.png)

- $A$ is the indicator of being randomized into the study
- $M$ is the indciator of being treated with Ivermectin, the river blindness medicine.
- Ivermectin is assumed to be commercially available, so $A=0$ group can still self-treat Ivermectin in their own discretion.
- $U$ is an unmeasured confounder, $S$ and $R$ lost due to fire.

---
## River Blindness Study 
-  Due to Ivermectin side-effects, an immunosuppressive therapy may be required at a nearby clinic established by the investigators.

- $S$ is the indicator of access to the clinic, and $R$ the indicator of immunosuppressive therapy. 



![bg right:40% width:95%](fig_swig2.png)

---
## River Blindness Study 

- The patients not selected into $A=1$ do not have access to immmunosuppression nor the clinic, thus $S=0$, $R=0$ for them. 

- $S=1$ iff $A=1$. 
- **No arrow from $U$ to $R(0, m)$ since $R(0, m) \equiv 0$.**
- **No arrow from $U$ to $M(1)$ since $a=1$ means randomized.**


![bg right:40% width:85%](fig_swig2.png)

---

## River Blindness Study 

### Are we allowed to ignore the inaccessible variables and simpify the diagram to the left version? No.
![width:300px](naive_dag.png) ![width:490px](fig_swig1.png)

---

## Cross-world confounding pathway
Consider the new SWIG.
$$M(a=0) \leftarrow U \rightarrow R(s=1, m) \rightarrow Y(s=1, m)$$

$$\text{Therefore, } \mathbf{M(a=0) \not\perp Y(s=1, m)}.$$
Recall that $A$ determines $S$ completely. In particular, $A=S$ and $S(a=1) = 1$ always holds. 

$$\therefore Y(s=1, m) = Y(a=1, m)$$


$$\textbf{Therefore, } \mathbf{Y(a=1, m) \not\perp M(a=0)}$$

![bg right:50% width:100%](SWIG_disprove_crossworld.png)


---

<style scoped>
section { font-size: 22px; }
</style>

## Andrews Bounds for the NDE/PDE

![bg right:58% contain](andrews_bounds.png)

When cross-world independence is violated, the mediation formula may be biased, so the NDE/PDE is **not point-identified**.

- The grey Andrews bounds give a **valid range** for the true NDE/PDE using only observable single-world quantities.

### Interpretation

The bounds are wider than a point estimate, but they remain robust when cross-world assumptions fail.

---

## Interventionist Framework (By Robins, motivated by Pearl)
### Robins, Richardson, Shpitser (2022)

---
## Pearl's Setup and an Argument on why PDE may be of interest

- $A$: smoking status (binary)
- $M$: hypertension status (binary)
- $Y$: outcome of myocardial infarction (MI) (binary)

**Setup: Nicotine is the only component of cigarette that affects $M$**

**Question of interest: Causal effect of providing nicotine-free cigarettes to smokers**
 
**Why?: They will have the hypertension level same as to that of the non-smokers, $M(a=0)$.** Thus, the following is an interesting quantity:
$$
PDE = E[Y(a=1, M(a=0))] - E[Y(a=0, M(a=0))]
$$

---
## Reformulation of the problem 

Let $O$ be other components of cigar then nicotine. $M$ is only affected by $N$, not $O$. 

$$
\mathbf{PDE = E[Y(n=0, o=1)] - E[Y(n=0, o=0)]}
$$

Consider 3 cases of the data:
1. The original observed data where **$\mathbf{A}$ was randomized**, $(A, M, Y)$. 
2. A "Desirable" data from **four-arm randomization of $\mathbf{(N, O)}$**, with counterfactuals $(M(n, o), Y(n, o))$ observed for $(n, o) \in \{0, 1\}^2$. 
3. **A censored version of the four-arm data**, where only $n=o$ cases are given to us.

![bg right:40% width:85%](interventionist_SWIG.png)

---
## Reformulation of the problem

We should see that data 1 allows us to identify the distribution of the data 3 by:
$$\begin{aligned}
p(M=m, Y=y | A=a) \\
&= p(M(n=a, o=a)=m, Y(n=a, o=a)=y | A=a) \\
&= p(M(n=a, o=a)=m, Y(n=a, o=a)=y)
\end{aligned}$$

The first line holds due to determinism $A=N=O$, and the second line holds from $\{M(n, o), Y(n, o)\} \perp A$ from the SWIG.

---
## Identification using the reformulated setup

Proposition 1 in  Robins et al. (2022):
**Under our SWIG, the 4-arm study's counterfactual outcomes are identifiable using the data of the $A$-randomized study.**


![bg right:40% width:85%](interventionist_SWIG.png)

---
## Efficient Estimation of the NDE
### TTS Estimator (Tchetgen Tchetgen & Shpitser, 2012)
---
<style scoped>
section { font-size: 22px; }
</style>

## Why Do We Need an Efficient Estimator?

The mediation g-formula identifies the NDE when A1–A4 hold:

$$
\text{NDE} = \sum_m \big(E[Y \mid A=1, M=m, L] - E[Y \mid A=0, M=m, L]\big)\, p(M=m \mid A=0, L)
$$

But naively plugging in parametric estimates:
- Inherits **model misspecification bias** from nuisance models
- Gives **no principled variance estimate** without the delta method

**Tchetgen Tchetgen & Shpitser (2012)** derive the **efficient influence function** for $E[Y(1, M(0))]$, giving an estimator that:
- Is **doubly robust** — consistent if either outcome or mediator model is correctly specified
- Achieves the **parametric $\sqrt{n}$ rate** even with nonparametric nuisance estimation
- Provides **IF-based variance** essentially for free

---
<style scoped>
section { font-size: 20px; }
</style>

## The TTS Influence Function

The NDE $= E[Y(1, M(0))] - E[Y(0, M(0))]$ is estimated via two influence functions.

**IF for** $E[Y(1, M(0))]$:

$$
\phi_{10} = \frac{\mathbf{1}(A=1)\, p(M \mid A=0, L)}{p(A=1 \mid L)\, p(M \mid A=1, L)} (Y - \mu_1) + \frac{\mathbf{1}(A=0)}{p(A=0 \mid L)}(\mu_1 - \eta_{10}) + \eta_{10}
$$

**IF for** $E[Y(0, M(0))]$:

$$
\phi_{00} = \frac{\mathbf{1}(A=0)}{p(A=0 \mid L)}(Y - \mu_0) + \eta_{00}
$$

where $\mu_a = E[Y \mid A=a, M, L]$ and $\eta_{a'a} = \sum_m E[Y \mid A=a', M=m, L]\, p(M=m \mid A=a, L)$

**NDE influence function:**

$$
\phi_{\text{NDE}} = \phi_{10} - \phi_{00}, \qquad \hat{\psi}_{\text{TTS}} = \frac{1}{n}\sum_{i=1}^n \phi_{\text{NDE},i}
$$

$$
\widehat{\text{SE}} = \sqrt{\frac{\widehat{\text{Var}}(\phi_{\text{NDE}})}{n}}, \qquad 95\%\ \text{CI} = \hat\psi \pm 1.96\cdot\widehat{\text{SE}}
$$

---

<style scoped>
section { font-size: 21px; }
</style>

## Simulation DGP: VanderWeele & Vansteelandt (2009), Figure 1

![bg right:38% width:95%](Dag_fig1_vanderweele.png)

The **clean identification setting** — all four assumptions A1–A4 hold.

$$C_1 \sim \text{Ber}(0.5), \quad C_2 \sim \text{Ber}(0.5)$$

$$A \mid C_1 \sim \text{Ber}\!\left(\text{logit}^{-1}(-0.5 + 1.0\, C_1)\right)$$

$$M \mid A, C_2 \sim \text{Ber}\!\left(\text{logit}^{-1}(-0.5 + 1.5\, A + 0.8\, C_2)\right)$$

$$Y \mid A, M, C_1, C_2 \sim \text{Ber}\!\left(\text{logit}^{-1}(-1.0 + 0.8\, A + 1.2\, M + 0.7\, C_1 + 0.6\, C_2)\right)$$

- $C_1$: baseline exposure–outcome confounder
- $C_2$: baseline mediator–outcome confounder
- **Neither is affected by $A$** → no intermediate confounding → cross-world independence holds

**True NDE** (Monte Carlo, $n = 10^6$): $\psi^* = 0.1619$

---

<style scoped>
section { font-size: 21px; }
</style>

## Estimation Setup

**Nuisance models** estimated via **SuperLearner** ensemble:
- `SL.glm` — logistic regression
- `SL.ranger` — random forest

Three nuisance quantities estimated per fold:
1. $\hat{p}(A=1 \mid C_1, C_2)$ — propensity score
2. $\hat{p}(M=1 \mid A, C_1, C_2)$ — mediator mechanism
3. $\hat{E}[Y \mid A, M, C_1, C_2]$ — outcome regression

**Cross-fitting:** $K = 5$ folds — nuisances trained on out-of-fold data and evaluated on held-out fold, preventing overfitting bias from propagating into the IF

**Variance:** estimated directly from the sample variance of $\phi_{\text{NDE},i}$, no bootstrap needed

---

<style scoped>
section { font-size: 22px; }
</style>

## Point Estimate and Validation

Running the TTS estimator on $n = 2000$ draws from the VanderWeele DGP:

| Quantity | Value |
|---|---|
| TTS Estimate $\hat\psi$ | **0.1700** |
| Standard Error | 0.0241 |
| 95% CI | (0.1228, 0.2171) |
| True NDE $\psi^*$ | **0.1619** |

- Bias: $0.1700 - 0.1619 = 0.0081$ — less than $\frac{1}{3}$ of a standard error
- True value **covered** by the 95% CI ✓
- IF-based SE is **well-calibrated** — CI has correct nominal coverage

This validates both the estimand (NDE, not just $E[Y(1, M(0))]$) and the cross-fitting implementation.

---

<style scoped>
section { font-size: 21px; }
</style>

## Convergence Rate Check

![bg right:55% width:100%](convergence_plot.png)

200 simulations at each $n \in \{100, 400, 900, 1600\}$

| $n$ | Bias | MSE | SE |
|---|---|---|---|
| 100 | $-0.010$ | $0.0169$ | $0.130$ |
| 400 | $0.006$ | $0.0037$ | $0.061$ |
| 900 | $0.002$ | $0.0015$ | $0.039$ |
| 1600 | $-0.001$ | $0.0009$ | $0.029$ |

- **MSE quarters as $n$ quadruples** → $1/n$ decay ✓
- **SE halves as $n$ quadruples** → $1/\sqrt{n}$ decay ✓
- **Bias shrinks to negligible** — cross-fitting removes nuisance bias ✓
- Blue line tracks red $1/n$ reference on log-log scale ✓
